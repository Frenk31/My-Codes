package it.epicode.azienda.sedelegaletest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;

public class SedeLegaleControllerTest extends BasicTests{

	@Override
	protected String getEntryPoint() {

		return "/sedelegale";
	}


	@Test
	void getAllSedeLegali() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void getAllSedeLegaliKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void getAllSedeLegaliNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void getAllSedeLegaliVia() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano1", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	@Test
	void getAllSedeLegaliViaKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano1", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void getAllSedeLegaleNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	
	@Test
	void getAllSedeLegaleNomeNotAuth() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano1", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}


	@Test
	void inserisciSedeLegaleKo() {
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}

	@Test
	void inserisciSedeLegaleNotAuth() {
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto);
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void inserisciSedeLegaleNotFound() {
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(3333333333333l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

	@Test
	void modificaSedeLegaleKo() {
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}

	@Test
	void modificaSedeLegaleNotAuth() {
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void modificaSedeLegaleNotFoundSedeLegale() {
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(323L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

	@Test
	void modificaSedeLegaleNotFoundComune() {
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(233232l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

	@Test
	void eliminaSedeLegale() {
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void eliminaSedeLegaleKo() {
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}

	@Test
	void eliminaSedeLegaleNotAuth() {
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}	
	
	@Test
	void eliminaSedeLegaleNotFound() {
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(23232323L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}


}
