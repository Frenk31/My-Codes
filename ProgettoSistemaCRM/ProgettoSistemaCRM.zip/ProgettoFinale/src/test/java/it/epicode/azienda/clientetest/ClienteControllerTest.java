package it.epicode.azienda.clientetest;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;

public class ClienteControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {
		
		return "/cliente";
	}
	
	@Test
	void getAllClienti() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void getAllClientiNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	
	@Test
	void getAllClientiNomeContatto() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiNomeConattoKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void getAllClientiNomeContattoNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	
	@Test
	void getAllClientiFatturatoAnnuale() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/200", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiFatturatoAnnualeKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlientinome/200", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void getAllClientiFatturaAnnualeNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlientinome/200", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	
	@Test
	void getAllClientiDataInserimento() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();
		dto.setData(LocalDate.now());		
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiDataInserimentoKo() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();	
		dto.setData(LocalDate.now());
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	@Test
	void getAllClientiDataInserimentoNotAuth() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();
		dto.setData(LocalDate.now());
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	
	@Test
	void getAllClientiDataUltimoContatto() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();
		dto.setData(LocalDate.now());		
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiDataUltimoContattoKo() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();	
		dto.setData(LocalDate.now());
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	@Test
	void getAllClientiDataUtlimoContattoNotAuth() {
		CercaPerDataResponseDTO dto = new CercaPerDataResponseDTO();
		dto.setData(LocalDate.now());
		HttpEntity<CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	@Test
	void getAllClientiProvincia() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);		
	}
	
	@Test
	void getAllClientiProvinciaKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void getAllClientiProvinciaNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
}
