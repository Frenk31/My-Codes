package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;
import it.epicode.azienda.dto.InserisciClienteRequestDTO;
import it.epicode.azienda.dto.ModificaClienteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.ClienteService;
/**
 * Classe Rest della classe Cliente
 * @author Francesco Donati
 */

@RestController
@RequestMapping("/cliente")
@Tag(name = "Cliente rest services", description = "Implementazioni dei diversi metodi di Cliente")
public class ClienteController {

	@Autowired
	ClienteService clienteService;


	@SuppressWarnings("rawtypes")
	@Operation (summary = "Inserisce un cliente nel db", description = "inserisce un cliente nel db ")
	@ApiResponse(responseCode = "200" , description = "cliente inserito con successo nel db !")
	@ApiResponse(responseCode ="404" , description = "Cliente non trovato")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscicliente" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisci(@Valid @RequestBody InserisciClienteRequestDTO dto) throws NotFoundException {
		clienteService.inserisciCliente(dto);
		return ResponseEntity.ok("CLIENTE INSERITO");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica un cliente presente nel db ", description = "Modifica un cliente presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="404" , description = "Cliente non trovato")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificacliente")
	public ResponseEntity modifica(@Valid @RequestBody ModificaClienteRequestDTO dto) throws NotFoundException {
		clienteService.modificaCliente(dto);
		return ResponseEntity.ok("CLIENTE MODIFICATO");
	}

	@SuppressWarnings("rawtypes")
	@Operation (summary = "Elimina un  cliente presente nel db", description = "Elimina un cliente presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="404" , description = "Cliente non Trovato ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminacliente")
	public ResponseEntity elimina(@Valid @RequestBody EliminaClienteRequestDTO dto ) throws NotFoundException {
		clienteService.eliminaCliente(dto);
		return ResponseEntity.ok("CLIENTE ELIMINATO");
	}
	

	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlienti")
	public ResponseEntity getAllClienti(Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClienti(page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db passando a parametro il nome del contatto", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientinome/{nomeContatto}")
	public ResponseEntity getAllClientiNomeContatto(@PathVariable("nomeContatto")String nomeContatto,Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClientiNome(nomeContatto,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db passando a parametro il fatturato annuale", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error Internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientifatturatoannuale/{fatturatoAnnuale}")
	public ResponseEntity getAllClientiFatturatoAnnuale(@PathVariable("fatturatoAnnuale") double fatturatoAnnuale,Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClientiFatturato(fatturatoAnnuale,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db passando a parametro la Data Inserimento", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error Internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tutticlientidatainserimento")
	public ResponseEntity getAllClientiDataInserimento(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClientiDataInserimento(dto,page));
	}

	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db passando a parametro la Data di ultimo Contatto", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error Internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tutticlientidataultimocontatto")
	public ResponseEntity getAllClientiDataUltimoContatto(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClientiDataUltimoContatto(dto,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutti i clienti presenti nel db passando a parametro la Provincia della Sede Legale", description = "Ritorna la lista di tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Clienti")
	@ApiResponse(responseCode ="500" , description = "Error Internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/cercaprovinciasedelegale/{provincia}")
	public ResponseEntity clienteSedeLegaleProvincia(@PathVariable("provincia")String provincia,Pageable page) {
		return ResponseEntity.ok(clienteService.cercaClientePerProvincia(provincia, page));
	}




}
