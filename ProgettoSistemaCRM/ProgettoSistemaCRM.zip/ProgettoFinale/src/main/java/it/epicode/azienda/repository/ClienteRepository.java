package it.epicode.azienda.repository;

import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.Cliente;

public interface ClienteRepository extends PagingAndSortingRepository<Cliente, Long>{
	
	Page<Cliente>findByNomeContattoContaining(String nomeContatto,Pageable page);
	
	Page<Cliente>findByFatturatoAnnuale(double fatturatoAnnuale,Pageable page);
	
	Page<Cliente>findByDataInserimento(LocalDate dataInserimento,Pageable page);
	
	Page<Cliente>findByDataUltimoContatto(LocalDate dataUltimoContatto,Pageable page);
	
	@Query("select cl from Cliente cl join cl.sedeLegale s join s.comune c join c.provincia p where p.provincia=?1  ")
	Page<Cliente>findByProvinciaSedeLegale(String provincia,Pageable Page);
	
}
