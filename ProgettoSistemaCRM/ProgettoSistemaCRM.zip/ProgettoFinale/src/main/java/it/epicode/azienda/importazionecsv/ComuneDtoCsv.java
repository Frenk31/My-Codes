package it.epicode.azienda.importazionecsv;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Questa classe viene utilizzata come DTO per l'importazione dei Comuni presenti nel file .csv
 * e il controllo della letterataura con il @JsonProperty(Specificando come viene scritta l'entità all'interno del .csv)
 * @author Francesco Donati
 */
@Data
@NoArgsConstructor
public class ComuneDtoCsv {
	
	@JsonProperty("comune")
	private String comune;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("CAP")
	private String cap;

}
