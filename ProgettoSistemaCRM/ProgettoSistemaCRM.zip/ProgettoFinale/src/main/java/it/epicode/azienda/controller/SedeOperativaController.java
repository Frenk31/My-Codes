package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaSedeOperativaRequestDTO;
import it.epicode.azienda.dto.InserisciSedeOperativaRequestDTO;
import it.epicode.azienda.dto.ModificaSedeOperativaRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.SedeOperativaService;
/**
 * Classe Rest della classe SedeOperativa
 * @author Francesco Donati
 */
@RestController
@RequestMapping("/sedeoperativa")
public class SedeOperativaController {

	@Autowired
	SedeOperativaService sedeOperativaService;
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Inserisce una nuova Sede Operativa nel db", description = "inserisce una Sede Operativa nel db ")
	@ApiResponse(responseCode = "200" , description = "Sede Operativa inserita con successo nel db !")
	@ApiResponse(responseCode ="403,404" , description = "Sede Operativa gia esistente o non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscisedeoperativa" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisci(@Valid @RequestBody InserisciSedeOperativaRequestDTO dto) throws NotFoundException {
		sedeOperativaService.inserisciSedeOperativa(dto);
			return ResponseEntity.ok("SEDE OPERATIVA INSERITA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica una Sede Operativa presente nel db ", description = "Modifica una Sede Operativa presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Modifica avvenuta")
	@ApiResponse(responseCode ="404" , description = "Sede Operativa non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificasedeoperativa")
	public ResponseEntity modifica(@Valid @RequestBody ModificaSedeOperativaRequestDTO dto) throws NotFoundException {
		sedeOperativaService.modificaSedeOperativa(dto);
		return ResponseEntity.ok("SEDE OPERATIVA MODIFICATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Elimina una Sede Operativa presente nel db", description = "Elimina una Sede Operativa presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Eliminazione avvenuta")
	@ApiResponse(responseCode ="404" , description = "Sede Operativa non Trovata ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminasedeoperativa")
	public ResponseEntity elimina(@Valid @RequestBody EliminaSedeOperativaRequestDTO dto ) throws NotFoundException {
		sedeOperativaService.eliminaSedeOperativa(dto);
		return ResponseEntity.ok("SEDE OPERATIVA ELIMINATA");
	}
	
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Sedi Operativa presenti nel db", description = "Ritorna la lista di tutte le Sedi Operativa presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Sedi Operativa")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedioperative")
	public ResponseEntity getAllSediOperative(Pageable page) {
		return ResponseEntity.ok(sedeOperativaService.cercaSedeOperativa(page));
	}
	
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Sedi Operativa presenti nel db passando la via a parametro", description = "Ritorna la lista di tutte le Sedi Operativa presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Sedi Operativa")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedioperativevia/{via}")
	public ResponseEntity getAllSediOperativeVia(@PathVariable("via")String via,Pageable page) {
		return ResponseEntity.ok(sedeOperativaService.cercaSedeOperativaVia(via,page));
	}
}
