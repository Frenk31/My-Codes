package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Provincia;
import it.epicode.azienda.repository.ProvinciaRepository;
/**
 * Classe Service di Provincia dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */

@Service
public class ProvinciaService {

	@Autowired
	ProvinciaRepository pr;

	/**
	 * Metodo che inserisci a DataBase una nuova Provincia
	 * @param dto
	 * @throws ElementAlreadyPresentException
	 */
	public void inserisciProvincia(InserisciProvinciaRequestDTO dto ) throws ElementAlreadyPresentException {
		if(!pr.existsById(dto.getSigla())) {
			Provincia p = new Provincia();
			BeanUtils.copyProperties(dto, p);
			pr.save(p);}
		else {
			throw new  ElementAlreadyPresentException("Provincia gia esistente");
		}
	}

	/**
	 * Metodo che elimina una provincia a DataBase 
	 * passando il corrispettivo Id
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaProvincia(EliminaProvinciaRequestDTO dto) throws NotFoundException {
		if(pr.existsById(dto.getSigla())) {
			Provincia p = pr.findById(dto.getSigla()).get();
			pr.delete(p);
		}else {
			throw new NotFoundException("provincia non trovata");
		}
	}

	/**
	 * Metodo che trova tutte le provice a DataBase 
	 * @param page
	 * @return
	 */
	public Page cercaProvincia(Pageable page) {
		return pr.findAll(page);

	}

	/**
	 * Metodo che modifica una Provincia a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaProvincia(ModificaProvinciaRequestDTO dto) throws NotFoundException {
		if(pr.existsById(dto.getSigla())) {
			Provincia p = pr.findById(dto.getSigla()).get();
			BeanUtils.copyProperties(dto, p);
			pr.save(p);

		}else{
			throw new  NotFoundException("provincia non trovata");
		}


	}

	/**
	 * Metodo che trova una Provicnia a DataBase 
	 * passando a parametro la Provincia 
	 * @param page
	 * @param provincia
	 * @return
	 */
	public Page cercaProvinciaNome(Pageable page,String provincia) {
		return pr.findByProvinciaContaining(page,provincia);
	}










}
