package it.epicode.azienda.repository;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.Fattura;

public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Long>{
	
	@Query("select f from Fattura f join f.cliente c ")
	Page<Fattura>findAllByCliente(Pageable page);
	
	@Query("select f from Fattura f join f.cliente c where c.id=?1")
	Page<Fattura>findByClienteId(Long id,Pageable page);
	
	Page<Fattura>findByStatoFattura( String statoFattura,Pageable page);
	
	Page<Fattura>findByData(LocalDate data,Pageable page);
	
	@Query("select f from Fattura f where f.data=?1")
	Page<Fattura>findByAnno(LocalDate data1,LocalDate date2,Pageable page);

	Page<Fattura>findByImporto(BigDecimal importo,Pageable page);
	
	@Query("select f from Fattura f where f.importo between ?1 and ?2")
	Page<Fattura>findAllByImporto(BigDecimal importo, BigDecimal importo2,Pageable page);
	

	

}
