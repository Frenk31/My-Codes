package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.SedeLegaleService;

/**
 * Classe Rest della classe SedeLegale
 * @author Francesco Donati
 */
@RestController
@RequestMapping("/sedelegale")
public class SedeLegaleController {

	
	@Autowired
	SedeLegaleService sedeLegaleService;
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Inserisce una nuova Sede Legale nel db", description = "inserisce una Sede Legale nel db ")
	@ApiResponse(responseCode = "200" , description = "Sede Legale inserita con successo nel db !")
	@ApiResponse(responseCode ="403,404" , description = "Sede Legale gia esistente o non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscisedelegale" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisci(@Valid @RequestBody InserisciSedeLegaleRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		sedeLegaleService.inserisciSedeLegale(dto);
			return ResponseEntity.ok("SEDE LEGALE INSERITA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica una Sede Legale presente nel db ", description = "Modifica una Sede Legale presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Modifica avvenuta")
	@ApiResponse(responseCode ="404" , description = "Sede Legale non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificasedelegale")
	public ResponseEntity modifica(@Valid @RequestBody ModificaSedeLegaleRequestDTO dto) throws NotFoundException {
		sedeLegaleService.modificaSedeLegale(dto);
		return ResponseEntity.ok("SEDE LEGALE MODIFICATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Elimina una Sede Legale presente nel db", description = "Elimina una Sede Legale presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Eliminazione avvenuta")
	@ApiResponse(responseCode ="404" , description = "Sede Legale non Trovata ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminasedelegale")
	public ResponseEntity elimina(@Valid @RequestBody EliminaSedeLegaleRequestDTO dto ) throws NotFoundException {
		sedeLegaleService.eliminaSedeLegale(dto);
		return ResponseEntity.ok("SEDE LEGALE ELIMINATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Sedi Legali presenti nel db", description = "Ritorna la lista di tutte le Sedi Legali presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Sedi Legali")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedilegali")
	public ResponseEntity getAllSediLegali(Pageable page) {
		return ResponseEntity.ok(sedeLegaleService.cercaSedeLegale(page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Sedi Legali presenti nel db passando la via a parametro", description = "Ritorna la lista di tutte le Sedi Legali presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Sedi Legali")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttesedilegalivia/{via}")
	public ResponseEntity getAllSediLegaliVia(@PathVariable("via")String via,Pageable page) {
		return ResponseEntity.ok(sedeLegaleService.cercaSedeLegaleVia(via,page));
	}
	
	
}
