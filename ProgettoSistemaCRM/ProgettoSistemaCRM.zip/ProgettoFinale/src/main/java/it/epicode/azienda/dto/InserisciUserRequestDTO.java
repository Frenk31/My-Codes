package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;



import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciUserRequestDTO {
	
	@NotBlank
	private String username;
	@NotBlank
	private String password;
	@NotBlank
	private String email;
	private String nome;
	private String cognome;



}
