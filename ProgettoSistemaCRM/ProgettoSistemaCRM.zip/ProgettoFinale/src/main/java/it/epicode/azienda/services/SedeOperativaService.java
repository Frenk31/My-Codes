package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaSedeOperativaRequestDTO;
import it.epicode.azienda.dto.InserisciSedeOperativaRequestDTO;
import it.epicode.azienda.dto.ModificaSedeOperativaRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.SedeOperativa;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.SedeOperativaRepository;

/**
 * Classe Service di SedeOperativa dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */
@Service
public class SedeOperativaService {
	
	@Autowired
	SedeOperativaRepository sor;
	@Autowired
	ComuneRepository cr;
	
	/**
	 * Metodo che inserisce a DataBase una nuova Sede Operativa
	 * @param dto
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException
	 */
	public void inserisciSedeOperativa(InserisciSedeOperativaRequestDTO dto) throws NotFoundException {
		SedeOperativa sedeOperativa = new SedeOperativa();
		BeanUtils.copyProperties(dto, sedeOperativa);
		if(cr.existsById(dto.getIdComune())) {
			Comune c = cr.findById(dto.getIdComune()).get();
			sedeOperativa.setComune(c);
			c.getSedeOperativa().add(sedeOperativa);
			sor.save(sedeOperativa);
		}else {
			throw new NotFoundException("Comune non trovato");
		}
	}

	/**
	 * Metodo che modfiica una determinata Sede Operativa a DataBase
	 * prendendola con l'Id che viene passato a parametro
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaSedeOperativa(ModificaSedeOperativaRequestDTO dto ) throws NotFoundException {
		if(sor.existsById(dto.getId())) {
			SedeOperativa sedeOperativa = sor.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, sedeOperativa);
			if(cr.existsById(dto.getIdComune())) {
				Comune c = cr.findById(dto.getIdComune()).get();
				c.getSedeOperativa().add(sedeOperativa);
				sedeOperativa.setComune(c);
				sor.save(sedeOperativa);
			}else {
				throw new  NotFoundException("comune non trovato");
			}
		}else {
			throw new NotFoundException("sede operativa non trovata");
		}

	}
	
	/**
	 * Metodo che elimina una determinata SedeOperativa a DataBase 
	 * passando a parametro l'id associato ad essa
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaSedeOperativa(EliminaSedeOperativaRequestDTO dto) throws NotFoundException {
		if(sor.existsById(dto.getId())) {
			SedeOperativa so=sor.findById(dto.getId()).get();
			so.getCliente().setSedeOperativa(null);
			so.setCliente(null);
			so.setComune(null);
			sor.save(so);
			so=sor.findById(dto.getId()).get();
			sor.delete(so);
		}
		else {
			throw new NotFoundException("sede operativa non trovata");
		}
		
	}
	

	/**
	 * Metodo che trova tutte le Sedi Operative presenti a DataBAse
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaSedeOperativa(Pageable page) {
		return sor.findAll(page);
		
	}
	
	/**
	 * Metodo che trova una determinata Sede Operativa 
	 * passando a parametro una determinata Via
	 * @param via
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaSedeOperativaVia(String via,Pageable page) {
		return sor.findByViaContaining(page, via);
	}
	
	
	



}
