package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.Provincia;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.ProvinciaRepository;
import lombok.extern.slf4j.Slf4j;

/**
 * Classe Service di Comune dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */
@Service
@Slf4j
public class ComuneService {
	@Autowired
	ComuneRepository cr;
	@Autowired
	ProvinciaRepository pr;

	/**
	 * Metodo che Inserisce un nuovo Comune a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void inserisciComune(InserisciComuneRequestDTO dto) throws NotFoundException{
		log.info("======================================================= dentro il metodo service di inserisci comune");
		Comune c = new Comune();
		BeanUtils.copyProperties(dto, c);
		if(pr.existsById(dto.getSiglaProvincia())) {
			log.info("======================================================= dentro l'if del metodo service di inserisci comune(Sigla Provincia)");
			Provincia p = pr.findById(dto.getSiglaProvincia()).get();
			c.setProvincia(p);
			p.getComune().add(c);
			cr.save(c);		
		}
		else {
			throw new NotFoundException("provincia non trovata");
		}
	}

	/**
	 * Metodo che Modifica un Comune presente a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaComune(ModificaComuneRequestDTO dto) throws NotFoundException {
		if(cr.existsById(dto.getId())) {
			log.info("======================================================= dentro l'if del metodo service di modifica Comune (Verifica di esistenza)");
			Comune c = cr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, c);
			if(pr.existsById(dto.getSiglaProvincia())) {
				log.info("======================================================= dentro l'if del metodo service di modifica Comune(Sigla Provincia)");
				Provincia p = pr.findById(dto.getSiglaProvincia()).get();
				p.getComune().add(c);
				c.setProvincia(p);
				cr.save(c);
			}else {
				throw new NotFoundException("provincia non trovata");
			}

		}else {
			throw new NotFoundException("comune non trovato");
		}
	}

	/**
	 * Metodo che Elimina un Comune presente a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaComune(EliminaComuneRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di elimina comune");
		if(cr.existsById(dto.getId())) {
			log.info("======================================================= dentro l'if del metodo elimina Comune");
			cr.deleteById(dto.getId());
		}
		else {
			throw new NotFoundException("comune non trovato");
		}
	}

	/**
	 * Metodo che trova tutti i Comuni presenti a DataBase
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaComune(Pageable page) {
		return cr.findAll(page);
	}


	/**
	 * Metodo che trova tutti i comuni 
	 * passando a parametro il nome
	 * @param page
	 * @param nome
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaComuneNome(Pageable page,String nome) {
		return cr.findByNomeContaining(page, nome);
	}








}
