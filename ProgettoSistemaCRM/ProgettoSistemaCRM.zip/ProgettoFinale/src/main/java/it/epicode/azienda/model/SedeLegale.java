package it.epicode.azienda.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Sedi_legali")
public class SedeLegale {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
	 private String via;
	 private String localita;
	 private String cap;
	 
	 @JsonIgnoreProperties({"sedeLegale"})
	 @OneToOne(mappedBy = "sedeLegale",cascade = {CascadeType.MERGE,CascadeType.PERSIST})
	 private Cliente cliente;
	
	 @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.PERSIST})
	 @JoinColumn(name = "id_comune",nullable = true)
	 private Comune comune;

}
