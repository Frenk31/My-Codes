package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.SedeLegale;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.SedeLegaleRepository;

/**
 * Classe Service di SedeLegale dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */
@Service
public class SedeLegaleService {

	@Autowired
	SedeLegaleRepository slr;
	@Autowired
	ComuneRepository cr;


	/**
	 * Metodo che inserisce a DataBase una nuova Sede Legale
	 * @param dto
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException
	 */
	public void inserisciSedeLegale(InserisciSedeLegaleRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		SedeLegale sedeLegale = new SedeLegale();
		BeanUtils.copyProperties(dto, sedeLegale);
		if(cr.existsById(dto.getIdComune())) {
			Comune c = cr.findById(dto.getIdComune()).get();
			if(c.getSedeLegale()== null) {
				sedeLegale.setComune(c);
				c.getSedeLegale().add(sedeLegale);
				slr.save(sedeLegale);
			}else {
				throw new ElementAlreadyPresentException("il Comune con id "+ dto.getIdComune() + " ha gia una sede operativa");
			}
		}else {
			throw new NotFoundException("comune non trovato");
		}
	}
	
	/**
	 * Metodo che modfiica una determinata Sede Legale a DataBase
	 * prendendola con l'Id che viene passato a parametro
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaSedeLegale(ModificaSedeLegaleRequestDTO dto ) throws NotFoundException {
		if(slr.existsById(dto.getId())) {
			SedeLegale sedeLegale = slr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, sedeLegale);
			if(cr.existsById(dto.getIdComune())) {
				Comune c = cr.findById(dto.getIdComune()).get();
				if(c.getSedeLegale()== null || c.getSedeLegale() != c.getSedeLegale()) {
					c.getSedeLegale().add(sedeLegale);
					sedeLegale.setComune(c);
					slr.save(sedeLegale);
				}else {
					throw new  NotFoundException("comune ha gia una sede operativa");
				}
			}else {
				throw new NotFoundException("comune  non trovato");
			}
		}else {
			throw new NotFoundException("sede Legale  non trovato");
		}


	}

	/**
	 * Metodo che elimina una determinata SedeLegale a DataBase 
	 * passando a parametro l'id associato ad essa
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaSedeLegale(EliminaSedeLegaleRequestDTO dto) throws NotFoundException {
		if(slr.existsById(dto.getId())) {
			SedeLegale sl = slr.findById(dto.getId()).get();
			sl.getCliente().setSedeLegale(null);
			sl.setCliente(null);
			sl.setComune(null);
			slr.delete(sl);
		}
		else {
			throw new NotFoundException("sede legale non trovata");
		}

	}
	
	/**
	 * Metodo che trova tutte le Sedi Legali presenti a DataBAse
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaSedeLegale(Pageable page) {
		return slr.findAll(page);

	}
	
	/**
	 * Metodo che trova una determinata Sede Legale 
	 * passando a parametro una determinata Via
	 * @param via
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaSedeLegaleVia(String via,Pageable page) {
		return slr.findByViaContaining(page, via);
	}






}
