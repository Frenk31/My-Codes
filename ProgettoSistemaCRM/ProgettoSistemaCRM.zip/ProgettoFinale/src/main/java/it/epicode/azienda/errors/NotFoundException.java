package it.epicode.azienda.errors;
/**
 * Creazione eccezione per un elemento non trovato
 */
@SuppressWarnings("serial")
public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);
		
	}

}
