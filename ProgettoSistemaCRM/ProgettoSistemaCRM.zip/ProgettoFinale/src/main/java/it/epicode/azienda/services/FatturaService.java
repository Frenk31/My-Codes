package it.epicode.azienda.services;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.CambiaLoDellaStatoFatturaRequestDTO;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaFatturaRequestDTO;
import it.epicode.azienda.dto.InserisciFatturaRequestDTO;
import it.epicode.azienda.dto.ModificaFatturaRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Cliente;
import it.epicode.azienda.model.Fattura;
import it.epicode.azienda.repository.ClienteRepository;
import it.epicode.azienda.repository.FatturaRepository;
import lombok.extern.slf4j.Slf4j;
/**
 * Classe Service di Fattura dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */
@Service
@Slf4j
public class FatturaService {

	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;

	/**
	 * Metodo che Inserisce una nuova Fattura a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void inserisciFattura(InserisciFatturaRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di inserisci fattura");
		Fattura fattura = new Fattura();
		BeanUtils.copyProperties(dto, fattura);
		if(cr.existsById(dto.getIdCliente())) {
			log.info("======================================================= dentro l'if del metodo service di inserisci fattura");
			Cliente cliente = cr.findById(dto.getIdCliente()).get();
			fattura.setCliente(cliente);
			cliente.getFattura().add(fattura);
			fr.save(fattura);

		}
		else {
			throw new NotFoundException("fattura non trovata");
		}

	}

	/**
	 * Metodo che modifica una Fattura presente a DataBase 
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaFattura(ModificaFatturaRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di modifica fattura");
		if(fr.existsById(dto.getNumero())) {
			log.info("======================================================= dentro l'if del metodo service di modifica fattura(Esistenza della fattura)");
			Fattura fattura = fr.findById(dto.getNumero()).get();
			BeanUtils.copyProperties(dto, fattura);
			if(cr.existsById(dto.getIdCliente())) {
				log.info("======================================================= dentro l'if del metodo service di modifica fattura(Esistenza del cliente)");
				Cliente cliente = cr.findById(dto.getIdCliente()).get();
				fattura.setCliente(cliente);
				cliente.getFattura().add(fattura);
				fr.save(fattura);
			}else {
				throw new NotFoundException("cliente non trovato");
			}
		}else {
			throw new NotFoundException("fattura non trovata");
		}

	}

	/**
	 * Metodo che elimina una fattura presente a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaFattura(EliminaFatturaRequestDTO dto) throws NotFoundException {
		if(fr.existsById(dto.getNumero())) {
			Fattura fattura = fr.findById(dto.getNumero()).get();
			fr.delete(fattura);
		}
		else {
			throw new NotFoundException("fattura non trovata");
		}	
	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaFattura(Pageable page) {
		return fr.findAll(page);

	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase del cliente
	 * che viene inserito a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClienti(Pageable page) {
		return fr.findAllByCliente(page);
	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * dell'id del cliente che viene messo a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClienteid(Long id, Pageable page) {
		return fr.findByClienteId(id, page);
	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * filtrandole con il tipo di Stato fattura
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaStatoFattura(String statoFattura,Pageable page) {
		return fr.findByStatoFattura(statoFattura, page);

	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * filtrandole con la data che viene messa a parametro 
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaPerData(CercaPerDataResponseDTO dto, Pageable page) {
		return fr.findByData(dto.getData(), page);
	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * filtrandole con l'importo che viene scelto a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaPerImporto(BigDecimal importo,Pageable page) {
		return fr.findByImporto(importo, page);
	}

	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * filtrandole con un range di importi che viene scelto a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaPerRangeImporto(BigDecimal importo,BigDecimal importo2, Pageable page) {
		return fr.findAllByImporto(importo, importo2, page);
	}


	/**
	 * Metodo che Trova tutte le Fatture presenti a DataBase
	 * filtrandole con solamente l'anno passato a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaPerAnno(String anno, Pageable page) {
		LocalDate data1 = LocalDate.parse(anno + "-01-01");
		LocalDate data2 = LocalDate.parse(anno + "-12-31");
		return fr.findByAnno(data1,data2, page);
	}


	/**
	 * Metodo che cambia lo Stato di una determinata fattura 
	 * trovandola passando l'id della fattura
	 * @param dto
	 * @throws NotFoundException
	 */
	public void cambiaLoStatoFattura(CambiaLoDellaStatoFatturaRequestDTO dto) throws NotFoundException {
		if(fr.existsById(dto.getNumero())) {
			Fattura f = fr.findById(dto.getNumero()).get();
			f.setStatoFattura(dto.getStatoFattura());
			fr.save(f);
		}
		else {
			throw new NotFoundException("fattura non trovata");
		}
	}


}
