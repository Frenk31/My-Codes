package it.epicode.azienda.importazionecsv;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Questa classe viene utilizzata come DTO per l'importazione delle province presenti nel file .csv
 * e il controllo della letterataura con il @JsonProperty(Specificando come viene scritta l'entità all'interno del .csv)
 * @author Francesco Donati
 */
@Data
@NoArgsConstructor
public class ProvinciaDtoCsv {
	@JsonProperty("sigla")
	private String sigla;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("Regione")
	private String regione;
	

}
