package it.epicode.azienda.controller;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.CambiaLoDellaStatoFatturaRequestDTO;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaFatturaRequestDTO;
import it.epicode.azienda.dto.InserisciFatturaRequestDTO;
import it.epicode.azienda.dto.ModificaFatturaRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.FatturaService;
/**
 * Classe Rest della classe Fattura
 * @author Francesco Donati
 */
@RestController
@RequestMapping("/fattura")
public class FatturaController {

	@Autowired
	FatturaService fatturaService;
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Inserisce una nuova Fattura nel db", description = "inserisce una Fattura nel db ")
	@ApiResponse(responseCode = "200" , description = "Fattura inserita con successo nel db !")
	@ApiResponse(responseCode ="404" , description = "Fattura non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscifattura" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisci(@Valid @RequestBody InserisciFatturaRequestDTO dto) throws NotFoundException {
		fatturaService.inserisciFattura(dto);
			return ResponseEntity.ok("FATTURA INSERITA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica una Fattura presente nel db ", description = "Modifica una Fattura presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Modifica avvenuta")
	@ApiResponse(responseCode ="404" , description = "Fattura non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificafattura")
	public ResponseEntity modifica(@Valid @RequestBody ModificaFatturaRequestDTO dto) throws NotFoundException {
		fatturaService.modificaFattura(dto);
		return ResponseEntity.ok("FATTURA MODIFICATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Elimina una fattura presente nel db", description = "Elimina una fattura presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Eliminazione avvenuta")
	@ApiResponse(responseCode ="404" , description = "Fattura non Trovata ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminafattura")
	public ResponseEntity elimina(@Valid @RequestBody EliminaFatturaRequestDTO dto ) throws NotFoundException {
		fatturaService.eliminaFattura(dto);
		return ResponseEntity.ok("FATTURA ELIMINATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefatture")
	public ResponseEntity getAllFatture(Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaFattura(page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando Il cliente a parametro", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientifattura")
	public ResponseEntity tuttiClientiFattura(Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaClienti(page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando l'ID del cliente a parametro", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientiid/{id}")
	public ResponseEntity tuttiClientiId(@PathVariable("id")Long id,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaClienteid(id,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando lo Stato della Fattura a parametro", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientistatofattura/{statoFattura}")
	public ResponseEntity tuttiClientiStatoFattura(@PathVariable("statoFattura")String statoFattura,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaStatoFattura(statoFattura,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando la data della Fattura a parametro", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tuttefatturedata")
	public ResponseEntity tutteFatturePerData(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaPerData(dto,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando passando l'importo a parametro ", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefattureperimporto/{importo}")
	public ResponseEntity tutteFatturePerImporto(@PathVariable("importo")BigDecimal importo,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaPerImporto(importo,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando un range di importi a parametro", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefattureperRangeimporto/{importo}/{importo2}")
	public ResponseEntity tutteFatturePerRangeImporto(@PathVariable("importo")BigDecimal importo,BigDecimal importo2,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaPerRangeImporto(importo, importo2, page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Fatture presenti nel db passando solamente l'anno della Fattura", description = "Ritorna la lista di tutte le Fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "Lista Fatture")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tuttefattureanno/{anno}")
	public ResponseEntity tutteFatturePerAnno(@PathVariable("anno") String anno,Pageable page) {
		return ResponseEntity.ok(fatturaService.cercaPerAnno(anno,page));
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica lo Stato di una fattura presente a DataBase")
	@ApiResponse(responseCode = "200" , description = "Modifica Avvenuta")
	@ApiResponse(responseCode ="404" , description = "Fattura non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificafatturastatofattura")
	public ResponseEntity modificaStatoFattura(@Valid @RequestBody CambiaLoDellaStatoFatturaRequestDTO dto) throws NotFoundException {
		fatturaService.cambiaLoStatoFattura(dto);
		return ResponseEntity.ok("STATO FATTURA MODIFICATO");
	}
	
}
