package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EliminaProvinciaRequestDTO {
	
	@NotBlank(message = "il campo non deve essere vuoto!")
	private String sigla;
}
