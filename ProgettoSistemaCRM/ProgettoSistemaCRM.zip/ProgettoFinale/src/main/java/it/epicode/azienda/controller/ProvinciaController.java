package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.ProvinciaService;
/**
 * Classe Rest della classe Provincia
 * @author Francesco Donati
 */

@RestController
@RequestMapping("/provincia")
public class ProvinciaController {

	@Autowired
	ProvinciaService provinciaService;
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Inserisce una nuova provincia nel db", description = "inserisce una provincia nel db ")
	@ApiResponse(responseCode = "200" , description = "Provincia inserita con successo nel db !")
	@ApiResponse(responseCode ="403" , description = "Provincia gia esistente")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciprovincia" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisci(@Valid @RequestBody InserisciProvinciaRequestDTO dto) throws  ElementAlreadyPresentException {
		provinciaService.inserisciProvincia(dto);
			return ResponseEntity.ok("PROVINCIA INSERITA");
	}
	

	@SuppressWarnings("rawtypes")
	@Operation (summary = "Modifica una Provincia presente nel db ", description = "Modifica una Provicnia presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Modifica avvenuta")
	@ApiResponse(responseCode ="404" , description = "Provincia non trovata")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaprovincia")
	public ResponseEntity modificaprovincia(@Valid @RequestBody ModificaProvinciaRequestDTO dto) throws NotFoundException {
		provinciaService.modificaProvincia(dto);
		return ResponseEntity.ok("PROVINCIA MODIFICATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Elimina una Provincia presente nel db", description = "Elimina una provincia presente nel db ")
	@ApiResponse(responseCode = "200" , description = "Eliminazione avvenuta")
	@ApiResponse(responseCode ="404" , description = "Provincia non Trovata ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaprovincia")
	public ResponseEntity elimina(@Valid @RequestBody EliminaProvinciaRequestDTO dto ) throws NotFoundException {
		provinciaService.eliminaProvincia(dto);
		return ResponseEntity.ok("PROVINCIA ELIMINATA");
	}
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Province presenti nel db", description = "Ritorna la lista di tutte le Province presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Province")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutteprovince")
	public ResponseEntity getAllProvince(Pageable page) {
		return ResponseEntity.ok(provinciaService.cercaProvincia(page));
	}
	
	
	@SuppressWarnings("rawtypes")
	@Operation (summary = "Ritorna tutte le Province presenti nel db passando il nome a parametro", description = "Ritorna la lista di tutte le Province presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista Province")
	@ApiResponse(responseCode ="500" , description = "Error internal Server")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutteprovincenome/{provincia}")
	public ResponseEntity getAllProvinceNome(@PathVariable("provincia")String provincia,Pageable page) {
		return ResponseEntity.ok(provinciaService.cercaProvinciaNome(page,provincia));
	}
	
	
}
