package it.epicode.azienda.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.Comune;

public interface ComuneRepository extends PagingAndSortingRepository <Comune,Long >{
	
	Page <Comune>findByNomeContaining(Pageable page,String nome);

}
