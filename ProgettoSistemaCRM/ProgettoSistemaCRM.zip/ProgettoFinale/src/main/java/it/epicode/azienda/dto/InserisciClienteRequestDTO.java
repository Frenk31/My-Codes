package it.epicode.azienda.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import it.epicode.azienda.model.ECliente;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciClienteRequestDTO {

	static final String DATE_PATTERN ="dd/MM/yyyy";


	private String ragioneSociale;
	private String partitaIva;
	private String email;
	@Schema(example = "20/02/2000", type = "string")	
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate dataInserimento;
	@Schema(example = "20/02/2000", type = "string")	
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate dataUltimoContatto;
	@NotNull(message = "il campo fatturato annuale non deve essere vuoto")
	private double fatturatoAnnuale;
	private String pec;
	@Schema(example = "Puoi inserire solo uno dei seguenti PA,SAS,SPA,SRL")
	private ECliente tipoCliente;
	private String telefono;
	private String emailContatto;
	@NotBlank(message = "il nome non deve essere vuoto")
	private String nomeContatto;
	@NotBlank(message = "il cognome non devessere vuoto")
	private String cognomeContatto;
	private String telefonoContatto;
	@NotNull(message = "il campo id sede legale non deve essere vuoto")
	private Long idSedeLegale;
	@NotNull(message = "il campo id sede operativa non deve essere vuoto")
	private Long idSedeOperativa;

}
