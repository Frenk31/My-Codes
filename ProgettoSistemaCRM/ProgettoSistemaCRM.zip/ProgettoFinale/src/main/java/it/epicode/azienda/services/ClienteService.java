package it.epicode.azienda.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;
import it.epicode.azienda.dto.InserisciClienteRequestDTO;
import it.epicode.azienda.dto.ModificaClienteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Cliente;
import it.epicode.azienda.model.SedeLegale;
import it.epicode.azienda.model.SedeOperativa;
import it.epicode.azienda.repository.ClienteRepository;
import it.epicode.azienda.repository.SedeLegaleRepository;
import it.epicode.azienda.repository.SedeOperativaRepository;
import lombok.extern.slf4j.Slf4j;
/**
 * Classe Service di Cliente dove vengono instanziati tutti i metodi 
 * necessari e che vengono richiesti dal progetto.
 * @author Franceso Donati
 */
@Service
@Slf4j
public class ClienteService {
	@Autowired
	ClienteRepository cr;
	@Autowired
	SedeLegaleRepository slr;
	@Autowired
	SedeOperativaRepository sor;

	/**
	 * Metodo che Inserisce un nuovo Cliente a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void inserisciCliente(InserisciClienteRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di inserisci cliente");
		Cliente cl = new Cliente();
		BeanUtils.copyProperties(dto, cl);
		if(slr.existsById(dto.getIdSedeLegale())) {
			log.info("======================================================= dentro l'if del metodo service di inserisci cliente (Sede Legale)");
			SedeLegale sedeLegale = slr.findById(dto.getIdSedeLegale()).get();
			sedeLegale.setCliente(cl);
			cl.setSedeLegale(sedeLegale);

		}else {
			throw new  NotFoundException("sede legale non trovata");
		}

		if(sor.existsById(dto.getIdSedeOperativa())) {
			log.info("======================================================= dentro l'if del metodo service di inserisci cliente (Sede Operativa)");
			SedeOperativa sedeOperativa = sor.findById(dto.getIdSedeOperativa()).get();
			sedeOperativa.setCliente(cl);
			cl.setSedeOperativa(sedeOperativa);

		}
		else {
			throw new NotFoundException("sede operativa non trovata");
		}

		cr.save(cl);
	}

	/**
	 * Metodo che modifica un cliente presente a DataBase 
	 * @param dto
	 * @throws NotFoundException
	 */
	public void	modificaCliente(ModificaClienteRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di modifica cliente");
		if(cr.existsById(dto.getId())) {
			Cliente cl = cr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, cl);
			if(slr.existsById(dto.getIdSedeLegale())) {
				log.info("======================================================= dentro l'if del metodo service di modifica cliente (Sede Legale)");
				SedeLegale sedeLegale = slr.findById(dto.getIdSedeLegale()).get();
				sedeLegale.setCliente(cl);
				cl.setSedeLegale(sedeLegale);

			}else {
				throw new  NotFoundException("sede legale non trovata");
			}

			if(sor.existsById(dto.getIdSedeOperativa())) {
				log.info("======================================================= dentro l'if del metodo service di modifica cliente (Sede Operativa)");
				SedeOperativa sedeOperativa = sor.findById(dto.getIdSedeOperativa()).get();
				sedeOperativa.setCliente(cl);
				cl.setSedeOperativa(sedeOperativa);

			}
			else {
				throw new NotFoundException("sede operativa non trovata");
			}

			cr.save(cl);
		}
	}

	/**
	 * Metodo che elimina un cliente presente a DataBase
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaCliente(EliminaClienteRequestDTO dto) throws NotFoundException {
		log.info("======================================================= dentro il metodo service di elimina cliente");
		if(cr.existsById(dto.getId())) {
			log.info("======================================================= dentro l'id del metodo service di elimina cliente");
			Cliente c = cr.findById(dto.getId()).get();
			cr.delete(c);
		}
		else {
			throw new NotFoundException("cliente non trovato");
		}
	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClienti(Pageable page) {
		return  cr.findAll(page);
	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase che sono associati al nome del Cliente 
	 * passato a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClientiNome(String nomeContatto,Pageable page) {
		return cr.findByNomeContattoContaining(nomeContatto, page);
	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase che sono associati al fatturato Annuale 
	 * passato a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClientiFatturato(double fatturatoAnnuale,Pageable page) {
		return cr.findByFatturatoAnnuale(fatturatoAnnuale, page);

	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase associati alla data di inserimento 
	 * passata a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClientiDataInserimento(CercaPerDataResponseDTO dto,Pageable page) {
		return cr.findByDataInserimento(dto.getData(), page);
	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase associati alla data di ultimo contatto
	 * passata a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClientiDataUltimoContatto(CercaPerDataResponseDTO dto,Pageable page) {

		return cr.findByDataUltimoContatto(dto.getData(), page);
	}

	/**
	 * Metodo che Trova tutti i clienti presenti a DataBase associati alla provincia 
	 * passata a parametro
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page cercaClientePerProvincia(String provincia, Pageable page) {
		return cr.findByProvinciaSedeLegale(provincia, page);
	}










}
