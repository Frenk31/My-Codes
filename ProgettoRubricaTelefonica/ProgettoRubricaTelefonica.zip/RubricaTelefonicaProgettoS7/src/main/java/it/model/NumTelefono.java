package it.model;


import java.io.Serializable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "numeri_telefonici")
public class NumTelefono implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String numTelefono;	
	private Contatto contatto;
	
	public NumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}
	public NumTelefono(int id, String numTelefono, Contatto contatto) {
		this.id = id;
		this.numTelefono = numTelefono;
		this.contatto = contatto;
	}
	public NumTelefono() {}
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	
	@Column(name = "num_telefono")
	public String getNumTelefono() {
		return numTelefono;
	}
	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}

	@ManyToOne
	@JoinColumn(name = "id_contatto")
	public Contatto getContatto() {
		return contatto;
	}
	public void setContatto(Contatto contatto) {
		this.contatto = contatto;
	}

	
}
