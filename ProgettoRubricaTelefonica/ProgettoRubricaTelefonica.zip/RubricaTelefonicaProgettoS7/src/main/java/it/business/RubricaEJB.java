package it.business;


import java.util.List;
import it.model.*;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

/**
 * Session Bean implementation class RubricaEJB
 */

@Stateless
@LocalBean
public class RubricaEJB {

    /**
     * Default constructor. 
     */
	
	@PersistenceContext(unitName = "rubricaPS")
	EntityManager em;
    public RubricaEJB() {}
    
    @SuppressWarnings("unchecked")
	public List<Contatto> cercaContattoPerNumero(String numero1, String numero2) {
    	
    	String sql = "Select c from Contatto c";
    	String where = null;
    	
    	if(numero1 != null) {
    		where = "WHERE c.numTelefoni =: numero1";		
    	}
    	
    	if(numero2 != null) {
    		if(where==null) {
    			where = "WHERE c.numTelefoni =: numero2";
    		} else {
	    		where += "AND c.numTelefoni =: numero2";
	    	} 	
	    }  
    	
    	if(where == null) where = "";
    	
    	sql = sql + where;
    	
    	Query q = em.createQuery(sql);
    	if(numero1!=null) q.setParameter("numero1", numero1);
    	if(numero2!=null) q.setParameter("numero2", numero2);
    	
    	return q.getResultList();
    }
    
    public List<Contatto> visualizzaTuttiIContatti() {
        return cercaContattoPerNumero(null, null);
    }
    
    public void inserisciContatto(String nome,String cognome, String email, String numero1, String numero2) {
        Contatto c = new Contatto(nome, cognome, email);
        int num1 = Integer.parseInt(numero1);
        int num2 = Integer.parseInt(numero2);
        NumTelefono nt1 = new NumTelefono(numero1);
        NumTelefono nt2 = new NumTelefono(numero2);
        c.getNumTelefoni().set(num1, nt1);
        c.getNumTelefoni().set(num2, nt2);
        inserisciContatto(c);
    }  
    public void inserisciContatto(Contatto c) {
    	em.persist(c);
    	
    }
    
    @SuppressWarnings("unchecked")
	public List<Contatto> cercaContattoPerCognome(String cognome){ 	
    	Query q = em.createNamedQuery("cerca.contatti.per.cognome");
    	q.setParameter("cognome%", cognome);
    	return q.getResultList();
    }
    
    @SuppressWarnings("unchecked")
	public List<Contatto> cercaContattoPerNumero(String numero){ 	
    	Query q = em.createNamedQuery("cerca.contatti.per.numero");
    	q.setParameter("num_Telefono", numero);   	
    	return (List<Contatto>) q.getSingleResult();
    }
    
    public void modificaNumeroContatto(Contatto c) {
    	em.merge(c);
    }
    
    public void modificaNumeroContatto(String id, String nome,String cognome, String email, String numero1, String numero2) {
    	int iId = Integer.parseInt(id);
        Contatto c = new Contatto(iId, nome, cognome, email);
        int num1 = Integer.parseInt(numero1);
        int num2 = Integer.parseInt(numero2);
        NumTelefono nt1 = new NumTelefono(numero1);
        NumTelefono nt2 = new NumTelefono(numero2);
        c.getNumTelefoni().set(num1, nt1);
        c.getNumTelefoni().set(num2, nt2);
        modificaNumeroContatto(c);
    }  
    
    
    public void eliminaContatto(String id, String nome,String cognome, String email, String numero1, String numero2) {
    	int iId = Integer.parseInt(id);
        Contatto c = new Contatto(iId, nome, cognome, email);
        int num1 = Integer.parseInt(numero1);
        int num2 = Integer.parseInt(numero2);
        NumTelefono nt1 = new NumTelefono(numero1);
        NumTelefono nt2 = new NumTelefono(numero2);
        c.getNumTelefoni().set(num1, nt1);
        c.getNumTelefoni().set(num2, nt2);
        eliminaContatto(c);
    }  
    
    
    public void eliminaContatto(Contatto c ) {
    	em.remove(em.merge(c));
    }
}
