package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import it.business.RubricaEJB;
import it.model.Contatto;

/**
 * Servlet implementation class VisualizzaContattiServlet
 */
@SuppressWarnings("unused")
public class VisualizzaContattiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@EJB
	RubricaEJB rejb;
    public VisualizzaContattiServlet() {
       
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Contatto> lc = rejb.visualizzaTuttiIContatti();
		
		for (Contatto contatti : lc) {
			response.getWriter()
				.append("<div>")
				.append("Nome")
				.append(contatti.getNome())
				.append("Cognome")
				.append(contatti.getCognome())
				.append("Email")
				.append(contatti.getEmail())
				.append("numero di telefono")
				.append((CharSequence) contatti.getNumTelefoni())
				
				;
		}

	}

}
